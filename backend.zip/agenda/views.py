from rest_framework import viewsets, status
from rest_framework.response import Response
from .models import Event
from .serializers import EventSerializer
from django.db.models import Q

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer

    def create(self, request, *args, **kwargs):
        start = request.data.get("start")
        end = request.data.get("end")

        # Vérifier s’il y a un chevauchement
        overlap = Event.objects.filter(
            Q(start__lt=end) & Q(end__gt=start)  # chevauchement
        ).exists()

        if overlap:
            return Response(
                {"error": "Ce créneau est déjà réservé."},
                status=status.HTTP_400_BAD_REQUEST
            )

        return super().create(request, *args, **kwargs)
